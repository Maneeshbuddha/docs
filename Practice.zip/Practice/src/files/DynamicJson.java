package files;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

import static io.restassured.RestAssured.*;

public class DynamicJson {
@Test(dataProvider="BooksData")
public void addBook(String isbn,String aisle) {
	RestAssured.baseURI="http://216.10.245.166";
String resp=given().log().all().header("Content-Type","application/json")
.body(Payload.addBook(isbn,aisle))
	.when()
	.post("Library/Addbook.php")
	.then().assertThat().statusCode(200)
	.extract().response().asString();
System.out.println(resp);
JsonPath js=ReUsableMethods.rawToJson(resp);
String id= js.get("ID");
System.out.println(id);

}
@Test(dataProvider="DeleteBookdata")
public void deleteBook(String id) {
	RestAssured.baseURI="http://216.10.245.166";
String resp1=given().log().all().header("Content-Type","application/json")
	.body(Payload.deleteBook(id))
	.when()
	.post("/Library/DeleteBook.php")
	.then().assertThat().statusCode(200)
	.extract().response().asString();
System.out.println(resp1);
JsonPath js=ReUsableMethods.rawToJson(resp1);
String msg= js.get("msg");
System.out.println(msg);

}
@DataProvider(name="DeleteBookdata")
public Object[][] deletedata() {
	return new Object[][]{{"abcdef1234"},{"ghijkl5678"},{"mnopqr9101112"}};
}
@DataProvider(name="BooksData")
public Object[][] getData() {
return new Object[][]{{"abcdef","1234"},{"ghijkl","5678"},{"mnopqr","9101112"}};
}
}
