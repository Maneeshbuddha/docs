package aug21;
import static io.restassured.RestAssured.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import groovy.transform.stc.POJO;
import io.github.bonigarcia.wdm.WebDriverManager;
import io.restassured.parsing.Parser;
import io.restassured.path.json.JsonPath;
import pojo.Api;
import pojo.GetCourse;
import pojo.WebAutomation;

public class oAuthTest {

	public static void main(String[] args) throws InterruptedException {
		/*WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.get("https://accounts.google.com/v3/signin/identifier?opparams=%253Fauth_url%253Dhttps%25253A%25252F%25252Faccounts.google.com%25252Fo%25252Foauth2%25252Fv2%25252Fauth&dsh=S1812357467%3A1694145829861916&client_id=692183103107-p0m7ent2hk7suguv4vq22hjcfhcr43pj.apps.googleusercontent.com&o2v=2&redirect_uri=https%3A%2F%2Frahulshettyacademy.com%2FgetCourse.php&response_type=code&scope=https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fuserinfo.email&service=lso&state=verifyfjdss&flowName=GeneralOAuthFlow&continue=https%3A%2F%2Faccounts.google.com%2Fsignin%2Foauth%2Fconsent%3Fauthuser%3Dunknown%26part%3DAJi8hAN3SzBwR8yxJYsKbscKaKRg7DZzPjF2xYdd28dNsNyT3rMkKR-AH-GOEXrfn-a_wJK7GTRCbqkPgv6QkOz-VzPyg8dbI2Jm2fv-Qe_HNKC1AWWHWanKPw_IIoqnPsOT6hez7qRqkD3_uogEvzHKPbKi7iVSByIsn5MXCQyS-AQjf-QFGlxCCLMEXm9TdmQW1NNv9Vctcq5oibaD2A9eNLshdSdKMPfOpiGH9DSs8ZiJi_fJIWUHujW0DGYY2r1xMwjyuEsq1xczPSn_XFSezsijpyOxvmmJQ1cxCtFz4A0swrkNzfpIBGWGva7zSC2CR3coGFuE_uqhstsXTJ7J7m7_k7HkXs8GWYtXVlGaznaFTTFwrqu1ue4M1dWBFRTojE-m5isnMHTJP7bmeBJOvuql0KkYF0hATWiRk2Mf4_9w00XCV3GBNIg5LncounP_tKKrIHFUXDeReQmaO8HJ95xeBc6EZg%26as%3DS1812357467%253A1694145829861916%26client_id%3D692183103107-p0m7ent2hk7suguv4vq22hjcfhcr43pj.apps.googleusercontent.com%23&app_domain=https%3A%2F%2Frahulshettyacademy.com&rart=ANgoxcfM0JdzaBvFua4o8ReDbo7g7Ro7LxDAEt5u1Z4hFKVIOuwSSKnD1b1GLGS7NkFle0ko875QL5A2O-u52omWi6GoJ1iBOw");
	driver.findElement(By.cssSelector("input[type='email']")).sendKeys("buddha.maneesh153@gmail.com");
	driver.findElement(By.cssSelector("input[type='email']")).sendKeys(Keys.ENTER);
		Thread.sleep(3000);
		driver.findElement(By.cssSelector("input[type='password']")).sendKeys("shiva123@");
		driver.findElement(By.cssSelector("input[type='password']")).sendKeys(Keys.ENTER);
		Thread.sleep(4000);
	String url=driver.getCurrentUrl();*/
	//String url="https://rahulshettyacademy.com/getCourse.php?state=verifyfjdss&code=4%2F0Adeu5BW3VJJncAS8jC0SKS_wakfMchPGudYeKda3WYyJzz7spBbc6n4cl7GN34MCZrA-eQ&scope=email+https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fuserinfo.email+openid&authuser=0&prompt=consent";
		String[] courseTitles= {"Selenium Webdriver Java","Cypress","Protractor"};
		String url="https://rahulshettyacademy.com/getCourse.php?state=verifyfjdss&code=4%2F0AfJohXlvZ05naiEwDrYJByH4yIN07we9coSXgxUTes_SIysFBWvRdnaRvEZujCOgjM-cnA&scope=email+openid+https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fuserinfo.email&authuser=0&prompt=none";
String partialcode=url.split("code=")[1];
String code=partialcode.split("&scope")[0];
System.out.println();
		
	String accessTokenresponse=given().urlEncodingEnabled(false)
			.queryParams("code",code)
		.queryParams("client_id","692183103107-p0m7ent2hk7suguv4vq22hjcfhcr43pj.apps.googleusercontent.com")
		.queryParams("client_secret","erZOWM9g3UtwNRj340YYaK_W")
		.queryParams("redirect_uri","https://rahulshettyacademy.com/getCourse.php")
		.queryParams("grant_type","authorization_code")
		.when().log().all()
		.post("https://www.googleapis.com/oauth2/v4/token").asString();
	JsonPath js=new JsonPath(accessTokenresponse);
	String accessToken=js.getString("access_token");
		
	/*String response=given().queryParam("access_token",accessToken)
		.when().
		get("https://rahulshettyacademy.com/getCourse.php").asString();*/
	
	GetCourse gc=given().queryParam("access_token",accessToken).expect().defaultParser(Parser.JSON)
			.when().
			get("https://rahulshettyacademy.com/getCourse.php").as(GetCourse.class);
System.out.println(gc.getLinkedIn());
System.out.println(gc.getInstructor());
System.out.println(gc.getServices());		
//System.out.println(response);
System.out.println(gc.getCourses().getApi().get(1).getCourseTitle());
 List<Api> apicourses=gc.getCourses().getApi();
 for(int i=0;i<apicourses.size();i++)
 {
	if(apicourses.get(i).getCourseTitle().equalsIgnoreCase("SoapUI Webservices testing"))
	{
	System.out.println(apicourses.get(i).getPrice());
	}
 }
 ArrayList<String> a=new ArrayList<String>();
List<WebAutomation> w=gc.getCourses().getWebAutomation();
for(int j=0;j<w.size();j++) {
a.add(w.get(j).getCourseTitle());
}
List<String> expectedList=Arrays.asList(courseTitles);
Assert.assertTrue(a.equals(expectedList));

	}

}
