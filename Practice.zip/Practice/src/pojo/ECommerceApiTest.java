package pojo;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import static io.restassured.RestAssured.*;

public class ECommerceApiTest {

	public static void main(String[] args) {
		
RequestSpecification req=new RequestSpecBuilder().setBaseUri("https://rahulshettyacademy.com")
.setContentType(ContentType.JSON).build();
LoginRequest loginrequest=new LoginRequest(); 
loginrequest.setUserEmail("buddha.maneesh153@gmail.com");
loginrequest.setUserPassword("Shiva123@");
RequestSpecification reqLogin= given().log().all().spec(req).body(loginrequest);
LoginResponse loginResponse=reqLogin.when().post("/api/ecom/auth/login").then().extract()
.response().as(LoginResponse.class);
System.out.println(loginResponse.getToken());
System.out.println(loginResponse.getUserId());
	}

}
